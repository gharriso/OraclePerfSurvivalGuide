grant all on TIMES to opsg; 
grant all on PRODUCTS to opsg; 
grant all on CHANNELS to opsg; 
grant all on PROMOTIONS to opsg; 
grant all on CUSTOMERS to opsg; 
grant all on COUNTRIES to opsg; 
grant all on SUPPLEMENTARY_DEMOGRAPHICS to opsg; 
 
grant all on CAL_MONTH_SALES_MV to opsg; 
grant all on FWEEK_PSCAT_SALES_MV to opsg; 
 
grant all on SALES_TRANSACTIONS_EXT to opsg; 
grant all on COSTS to opsg; 
grant all on SALES to opsg; 
  



