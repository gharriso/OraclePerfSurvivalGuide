alter system set "_ksmg_granule_size"=8m scope=spfile; 
alter system set "_flashback_generation_buffer_size"=8m scope=spfile; 

