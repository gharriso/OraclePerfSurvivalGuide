select name,round(bytes/1048576,2) mb , resizeable from v$sgainfo
