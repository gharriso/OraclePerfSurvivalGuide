select sum(amount_sold) from txn_data;
col event format a20 
select * from my_wait_view; 
