set serveroutput on 

begin
    gen_hit_rate.gen_hit_rate(&1); 
end;
/
