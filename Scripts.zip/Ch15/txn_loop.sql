begin
    txn_sim.txn_loop( &1 ) ;
end;
/

