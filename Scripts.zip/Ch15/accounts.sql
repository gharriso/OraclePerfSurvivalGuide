create table accounts (account_id number primary key, balance number); 
insert into accounts values(1,1000);
insert into accounts values(2,1000);
commit;

