select * from customers where cust_id=1 for update ; 
select * from customers where cust_id=2 for update ; 
