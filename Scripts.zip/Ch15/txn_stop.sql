begin
    txn_sim.txn_stop;
end;
/
exit;
