grant all on CUSTOMERS to opsg;
grant all on WAREHOUSES to opsg;
grant all on ORDER_ITEMS to opsg;
grant all on ORDERS to opsg;
grant all on INVENTORIES to opsg;
grant all on PRODUCT_INFORMATION to opsg;
grant all on PRODUCT_DESCRIPTIONS to opsg;
grant all on PROMOTIONS to opsg;
grant all on ORDERS_SEQ to opsg;
grant all on PURCHASEORDER to opsg;


