sqlplus /nolog @install_opsg
