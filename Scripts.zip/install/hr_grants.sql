grant all on employees to opsg; 
grant all on jobs to opsg; 
grant all on job_history to opsg; 
grant all on departments to opsg; 
grant all on locations to opsg; 
grant all on countries to opsg;
grant all on regions to opsg; 
grant all on employees_seq to opsg; 


